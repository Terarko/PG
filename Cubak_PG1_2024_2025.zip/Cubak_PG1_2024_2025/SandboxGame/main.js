/* main.js */

/***************************************************
 * (1) GAME STATE & MENUS (Unchanged from snippet)
 ***************************************************/
let gameState = "mainmenu";

const hotbarItems = [
    { label:"Grass/Dirt", icon:"textures/grass_top.png",  isSpecialGrass:true,  singleTextureId:0 },
    { label:"All Dirt",   icon:"textures/dirt.png",       isSpecialGrass:false, singleTextureId:1 },
    { label:"Bricks Gray",   icon:"textures/bricks_gray.png",   isSpecialGrass:false, singleTextureId:2 },
    { label:"Bricks Orange", icon:"textures/bricks_orange.png", isSpecialGrass:false, singleTextureId:3 },
    { label:"Plank Brown",   icon:"textures/plank_brown.png",   isSpecialGrass:false, singleTextureId:4 },
    { label:"Plank Dark",    icon:"textures/plank_dark.png",    isSpecialGrass:false, singleTextureId:5 },
    { label:"Plank Yellow",  icon:"textures/plank_yellow.png",  isSpecialGrass:false, singleTextureId:6 },
    { label:"Stone",         icon:"textures/stone.png",         isSpecialGrass:false, singleTextureId:7 },
    { label:"???",           icon:"textures/dirt.png",          isSpecialGrass:false, singleTextureId:8 }
];

const hotbarDiv = document.getElementById("hotbar");
hotbarItems.forEach((item, i)=>{
    const slot = document.createElement("div");
    slot.className = "hotbar-slot";
    slot.dataset.slotIndex = i;
    const img = document.createElement("img");
    img.src = item.icon;
    slot.appendChild(img);
    hotbarDiv.appendChild(slot);
});

let currentHotbarIndex=0;
function updateHotbarUI(){
    const slots = hotbarDiv.querySelectorAll(".hotbar-slot");
    slots.forEach((slot, i)=>{
        slot.classList.toggle("selected", i===currentHotbarIndex);
    });
}
updateHotbarUI();

document.addEventListener("keydown",(e)=>{
    const n = parseInt(e.key,10);
    if(!isNaN(n) && n>=1 && n<=9){
        currentHotbarIndex = n-1;
        updateHotbarUI();
    }
});

const startMenu   = document.getElementById("startMenu");
const pauseMenu   = document.getElementById("pauseMenu");
const startBtn    = document.getElementById("startBtn");
const resumeBtn   = document.getElementById("resumeBtn");
const quitBtn     = document.getElementById("quitBtn");

const gameCanvas  = document.getElementById("gameCanvas");
const gl          = gameCanvas.getContext("webgl");
if(!gl) throw new Error("WebGL not supported");

gameCanvas.width  = window.innerWidth;
gameCanvas.height = window.innerHeight;
gl.viewport(0,0, gameCanvas.width, gameCanvas.height);
gl.clearColor(0.8,0.8,0.8,1.0);
gl.enable(gl.DEPTH_TEST);

window.addEventListener("resize",()=>{
    gameCanvas.width  = window.innerWidth;
    gameCanvas.height = window.innerHeight;
    gl.viewport(0,0, gameCanvas.width, gameCanvas.height);
});

function setGameState(newState){
    gameState=newState;
    if(newState==="mainmenu"){
        startMenu.style.display ="block";
        pauseMenu.style.display ="none";
        gameCanvas.style.display="none";
        hotbarDiv.style.display ="none";
    } else if(newState==="ingame"){
        startMenu.style.display ="none";
        pauseMenu.style.display ="none";
        gameCanvas.style.display="block";
        hotbarDiv.style.display ="flex";
    } else if(newState==="paused"){
        startMenu.style.display ="none";
        pauseMenu.style.display ="block";
        gameCanvas.style.display="block";
        hotbarDiv.style.display ="flex";
    }
}

startBtn.addEventListener("click",()=>{
    setGameState("ingame");
});
resumeBtn.addEventListener("click",()=>{
    setGameState("ingame");
});
quitBtn.addEventListener("click",()=>{
    setGameState("mainmenu");
});

document.addEventListener("keydown",(e)=>{
    if(e.key==="Escape"){
        if(gameState==="ingame") setGameState("paused");
        else if(gameState==="paused") setGameState("ingame");
    }
});

/***************************************************
 * (2) SHADERS (Unchanged)
 ***************************************************/
const vsSource=`
attribute vec3 aPosition;
attribute vec2 aTexCoord;
attribute float aFaceType;

uniform mat4 uProjectionMatrix;
uniform mat4 uModelViewMatrix;

varying vec2 vTexCoord;
varying float vFaceType;

void main(){
  gl_Position = uProjectionMatrix * uModelViewMatrix * vec4(aPosition,1.0);
  vTexCoord = aTexCoord;
  vFaceType = aFaceType;
}
`;

const fsSource=`
precision mediump float;

uniform sampler2D uGrassTexture;
uniform sampler2D uDirtTexture;
uniform sampler2D uAllDirtTex;
uniform sampler2D uBricksGrayTex;
uniform sampler2D uBricksOrangeTex;
uniform sampler2D uPlankBrownTex;
uniform sampler2D uPlankDarkTex;
uniform sampler2D uPlankYellowTex;
uniform sampler2D uStoneTex;

uniform int uBlockType;

varying vec2 vTexCoord;
varying float vFaceType;

void main(){
  if(vFaceType < 0.5){
    gl_FragColor = texture2D(uGrassTexture, vTexCoord);
  }
  else if(vFaceType < 1.5){
    gl_FragColor = texture2D(uDirtTexture, vTexCoord);
  } else {
    if(uBlockType==1){
      gl_FragColor = texture2D(uAllDirtTex, vTexCoord);
    } else if(uBlockType==2){
      gl_FragColor = texture2D(uBricksGrayTex, vTexCoord);
    } else if(uBlockType==3){
      gl_FragColor = texture2D(uBricksOrangeTex, vTexCoord);
    } else if(uBlockType==4){
      gl_FragColor = texture2D(uPlankBrownTex, vTexCoord);
    } else if(uBlockType==5){
      gl_FragColor = texture2D(uPlankDarkTex, vTexCoord);
    } else if(uBlockType==6){
      gl_FragColor = texture2D(uPlankYellowTex, vTexCoord);
    } else if(uBlockType==7){
      gl_FragColor = texture2D(uStoneTex, vTexCoord);
    } else {
      gl_FragColor = texture2D(uDirtTexture, vTexCoord);
    }
  }
}
`;

function compileShader(type,src){
    const s= gl.createShader(type);
    gl.shaderSource(s,src);
    gl.compileShader(s);
    if(!gl.getShaderParameter(s, gl.COMPILE_STATUS)){
        console.error(gl.getShaderInfoLog(s));
        gl.deleteShader(s);
        return null;
    }
    return s;
}
const vs= compileShader(gl.VERTEX_SHADER, vsSource);
const fs= compileShader(gl.FRAGMENT_SHADER, fsSource);
const program= gl.createProgram();
gl.attachShader(program, vs);
gl.attachShader(program, fs);
gl.linkProgram(program);
if(!gl.getProgramParameter(program, gl.LINK_STATUS)){
    console.error("ProgramLinkError:", gl.getProgramInfoLog(program));
}
gl.useProgram(program);

const aPosLoc   = gl.getAttribLocation(program,"aPosition");
const aUVLoc    = gl.getAttribLocation(program,"aTexCoord");
const aFaceLoc  = gl.getAttribLocation(program,"aFaceType");

const uProjLoc  = gl.getUniformLocation(program,"uProjectionMatrix");
const uMVLoc    = gl.getUniformLocation(program,"uModelViewMatrix");
const uBlockType= gl.getUniformLocation(program,"uBlockType");

const FLOAT_SIZE=4;
const VERT_SIZE=6;
const STRIDE= VERT_SIZE*FLOAT_SIZE;
const POS_OFFSET= 0;
const UV_OFFSET=  3*FLOAT_SIZE;
const FT_OFFSET=  5*FLOAT_SIZE;

/***************************************************
 * (3) GEOMETRY #1: Grass/Dirt blocks (faceType=0/1)
 ***************************************************/
const grassDirtData= new Float32Array([
    // top => faceType=0
    -0.5,0.5,-0.5, 0,1, 0,
    0.5,0.5,-0.5,  1,1, 0,
    0.5,0.5, 0.5,  1,0, 0,
    -0.5,0.5, 0.5,  0,0, 0,

    // bottom => faceType=1
    -0.5,-0.5, 0.5, 0,1, 1,
    0.5,-0.5,  0.5, 1,1, 1,
    0.5,-0.5, -0.5,1,0, 1,
    -0.5,-0.5,-0.5,0,0, 1,

    // +X => faceType=1
    0.5,-0.5,-0.5, 0,1, 1,
    0.5,-0.5, 0.5,  1,1, 1,
    0.5, 0.5, 0.5,  1,0, 1,
    0.5, 0.5,-0.5,  0,0, 1,

    // -X => faceType=1
    -0.5,-0.5, 0.5, 0,1, 1,
    -0.5,-0.5,-0.5,1,1, 1,
    -0.5, 0.5,-0.5,1,0, 1,
    -0.5, 0.5, 0.5,  0,0, 1,

    // +Z => faceType=1
    -0.5,-0.5, 0.5, 0,1, 1,
    0.5,-0.5,  0.5, 1,1, 1,
    0.5, 0.5,  0.5, 1,0, 1,
    -0.5,0.5,  0.5, 0,0, 1,

    // -Z => faceType=1
    0.5,-0.5,-0.5, 0,1, 1,
    -0.5,-0.5,-0.5,1,1, 1,
    -0.5, 0.5,-0.5,1,0, 1,
    0.5, 0.5,-0.5, 0,0, 1
]);
const grassDirtIndices= new Uint16Array([
    0,1,2, 0,2,3,
    4,5,6, 4,6,7,
    8,9,10, 8,10,11,
    12,13,14, 12,14,15,
    16,17,18, 16,18,19,
    20,21,22, 20,22,23
]);
const grassDirtVBO= gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, grassDirtVBO);
gl.bufferData(gl.ARRAY_BUFFER, grassDirtData, gl.STATIC_DRAW);
const grassDirtIBO= gl.createBuffer();
gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, grassDirtIBO);
gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, grassDirtIndices, gl.STATIC_DRAW);

/***************************************************
 * (4) GEOMETRY #2: Single blocks (faceType=2)
 ***************************************************/
const singleData= new Float32Array([
    // top => faceType=2
    -0.5,0.5,-0.5, 0,1, 2,
    0.5,0.5,-0.5,  1,1, 2,
    0.5,0.5, 0.5,  1,0, 2,
    -0.5,0.5, 0.5,  0,0, 2,

    // bottom => faceType=2
    -0.5,-0.5, 0.5, 0,1, 2,
    0.5,-0.5,  0.5, 1,1, 2,
    0.5,-0.5, -0.5,1,0, 2,
    -0.5,-0.5,-0.5,0,0, 2,

    // +X => faceType=2
    0.5,-0.5,-0.5, 0,1, 2,
    0.5,-0.5, 0.5,  1,1, 2,
    0.5, 0.5, 0.5,  1,0, 2,
    0.5, 0.5,-0.5,  0,0, 2,

    // -X => faceType=2
    -0.5,-0.5, 0.5, 0,1, 2,
    -0.5,-0.5,-0.5,1,1, 2,
    -0.5, 0.5,-0.5,1,0, 2,
    -0.5, 0.5, 0.5,  0,0, 2,

    // +Z => faceType=2
    -0.5,-0.5, 0.5, 0,1, 2,
    0.5,-0.5,  0.5, 1,1, 2,
    0.5, 0.5,  0.5, 1,0, 2,
    -0.5, 0.5,  0.5, 0,0, 2,

    // -Z => faceType=2
    0.5,-0.5,-0.5, 0,1, 2,
    -0.5,-0.5,-0.5,1,1, 2,
    -0.5, 0.5,-0.5,1,0, 2,
    0.5, 0.5,-0.5, 0,0, 2
]);
const singleIndices= new Uint16Array([
    0,1,2, 0,2,3,
    4,5,6, 4,6,7,
    8,9,10, 8,10,11,
    12,13,14, 12,14,15,
    16,17,18, 16,18,19,
    20,21,22, 20,22,23
]);
const singleVBO= gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, singleVBO);
gl.bufferData(gl.ARRAY_BUFFER, singleData, gl.STATIC_DRAW);
const singleIBO= gl.createBuffer();
gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, singleIBO);
gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, singleIndices, gl.STATIC_DRAW);

/***************************************************
 * (5) Large plane "outerPlane" => y=-0.5 => grass
 ***************************************************/
const outerPlaneData=new Float32Array([
    -500, -0.5, -500,  0,50, 0,
    500, -0.5, -500, 50,50, 0,
    500, -0.5,  500, 50, 0, 0,
    -500, -0.5,  500,  0, 0, 0
]);
const outerPlaneIndices=new Uint16Array([0,1,2, 0,2,3]);
const outerPlaneVBO= gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, outerPlaneVBO);
gl.bufferData(gl.ARRAY_BUFFER, outerPlaneData, gl.STATIC_DRAW);

const outerPlaneIBO= gl.createBuffer();
gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, outerPlaneIBO);
gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, outerPlaneIndices, gl.STATIC_DRAW);

/***************************************************
 * (6) TEXTURES (Unchanged)
 ***************************************************/
function loadTexture(url, unit){
    const tex= gl.createTexture();
    gl.activeTexture(unit);
    gl.bindTexture(gl.TEXTURE_2D, tex);

    // pink placeholder
    const placeholder=new Uint8Array([255,0,255,255]);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,placeholder);

    const img=new Image();
    img.onload=()=>{
        gl.activeTexture(unit);
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    };
    img.src=url;
    return tex;
}
let texUnitCounter=0;
function nextUnit(){ return gl.TEXTURE0 + (texUnitCounter++); }

const grassTex        = loadTexture("textures/grass_top.png",   nextUnit());
const dirtTex         = loadTexture("textures/dirt.png",        nextUnit());
const allDirtTex      = loadTexture("textures/dirt.png",        nextUnit());
const bricksGrayTex   = loadTexture("textures/bricks_gray.png", nextUnit());
const bricksOrangeTex = loadTexture("textures/bricks_orange.png", nextUnit());
const plankBrownTex   = loadTexture("textures/plank_brown.png", nextUnit());
const plankDarkTex    = loadTexture("textures/plank_dark.png",  nextUnit());
const plankYellowTex  = loadTexture("textures/plank_yellow.png",nextUnit());
const stoneTex        = loadTexture("textures/stone.png",       nextUnit());
const extraTex        = loadTexture("textures/dirt.png",        nextUnit());

const uGrassLoc= gl.getUniformLocation(program,"uGrassTexture");
const uDirtLoc=  gl.getUniformLocation(program,"uDirtTexture");
const uAllDirtLoc= gl.getUniformLocation(program,"uAllDirtTex");
const uBricksGrayLoc= gl.getUniformLocation(program,"uBricksGrayTex");
const uBricksOrangeLoc= gl.getUniformLocation(program,"uBricksOrangeTex");
const uPlankBrownLoc=  gl.getUniformLocation(program,"uPlankBrownTex");
const uPlankDarkLoc=   gl.getUniformLocation(program,"uPlankDarkTex");
const uPlankYellowLoc= gl.getUniformLocation(program,"uPlankYellowTex");
const uStoneLoc=       gl.getUniformLocation(program,"uStoneTex");
function setTextureUniforms(){
    let i=0;
    gl.uniform1i(uGrassLoc,        i++);
    gl.uniform1i(uDirtLoc,         i++);
    gl.uniform1i(uAllDirtLoc,      i++);
    gl.uniform1i(uBricksGrayLoc,   i++);
    gl.uniform1i(uBricksOrangeLoc, i++);
    gl.uniform1i(uPlankBrownLoc,   i++);
    gl.uniform1i(uPlankDarkLoc,    i++);
    gl.uniform1i(uPlankYellowLoc,  i++);
    gl.uniform1i(uStoneLoc,        i++);
}
setTextureUniforms();

/***************************************************
 * (7) AUDIO (Unchanged)
 ***************************************************/
const buildAudio   = new Audio("sounds/build.mp3");
const destroyAudio = new Audio("sounds/destroy.mp3");

/***************************************************
 * (8) CAMERA & SCENE (Unchanged)
 ***************************************************/
let cameraPosition=[0,20,40];
let cameraRotation=[-0.4,0];
let isMiddleMouseDown=false;
let lastMousePos=[0,0];
const keyMap={};

function clampCamera(){
    const limit=49.0;
    if(cameraPosition[0]< -limit) cameraPosition[0]= -limit;
    if(cameraPosition[0]>  limit) cameraPosition[0]=  limit;
    if(cameraPosition[2]< -limit) cameraPosition[2]= -limit;
    if(cameraPosition[2]>  limit) cameraPosition[2]=  limit;
}

// 100×100 plane of blocks at y=0
const planeSize=100;
const blocks=[];
for(let x=-planeSize/2; x<planeSize/2; x++){
    for(let z=-planeSize/2; z<planeSize/2; z++){
        blocks.push({
            position:[x,0,z],
            blockTypeIndex:0, // grass/dirt by default
            deletable:false
        });
    }
}

/***************************************************
 * (8.5) NO-CLIP Toggle + Indicator
 ***************************************************/
let noClip = true; // Default: can pass through blocks
const noClipIndicator = document.getElementById("noClipIndicator");

function updateNoClipIndicator() {
    if (!noClipIndicator) return;
    noClipIndicator.textContent = "NoClip: " + (noClip ? "ON" : "OFF");
}
updateNoClipIndicator();

// Press "U" => toggle noClip
document.addEventListener("keydown",(e)=>{
    if (canInteract() && e.key.toLowerCase() === "u") {
        noClip = !noClip;
        updateNoClipIndicator();
    }
});

function canInteract(){
    return (gameState==="ingame");
}

/***************************************************
 * (9) EVENT LISTENERS (Wheel => move camera Y in small increments)
 ***************************************************/
gameCanvas.addEventListener("mousedown",(e)=>{
    if(!canInteract()) return;
    if(e.button===1){
        isMiddleMouseDown=true;
        lastMousePos=[e.clientX,e.clientY];
    }
});
gameCanvas.addEventListener("mousemove",(e)=>{
    if(!canInteract()) return;
    if(isMiddleMouseDown){
        const dx=e.clientX-lastMousePos[0];
        const dy=e.clientY-lastMousePos[1];
        lastMousePos=[e.clientX,e.clientY];

        cameraRotation[1]+= dx*0.005;
        cameraRotation[0]-= dy*0.005;
        cameraRotation[0]= Math.max(-Math.PI/2, Math.min(Math.PI/2,cameraRotation[0]));
    }
});
gameCanvas.addEventListener("mouseup",(e)=>{
    if(!canInteract()) return;
    if(e.button===1){
        isMiddleMouseDown=false;
    }
});
document.addEventListener("keydown",(e)=>{
    if(!canInteract()) return;
    keyMap[e.key.toLowerCase()]=true;
});
document.addEventListener("keyup",(e)=>{
    if(!canInteract()) return;
    keyMap[e.key.toLowerCase()]=false;
});
gameCanvas.addEventListener("mousedown",(e)=>{
    if(!canInteract()) return;
    if(e.button===2){
        handleBlockInteraction(e,"delete");
    } else if(e.button===0){
        handleBlockInteraction(e,"add");
    }
});

// Break large scroll delta into sub-steps to avoid forcing through blocks
gameCanvas.addEventListener("wheel",(e)=>{
    if(!canInteract()) return;
    e.preventDefault();

    // e.deltaY typically ~100 or so for big scroll jumps
    // We'll do, say, 10 sub-steps for collision checks
    const steps = 10;
    const scrollSpeed = 0.02; // 0.1 was bigger; let's reduce to 0.02 per step
    const totalMove = e.deltaY * scrollSpeed;
    const stepMove  = totalMove / steps;

    for (let i=0; i<steps; i++) {
        const oldY = cameraPosition[1];
        cameraPosition[1] += stepMove;

        if (!noClip && isCameraInsideAnyBlock(cameraPosition)) {
            // revert & stop further moves
            cameraPosition[1] = oldY;
            break;
        }
    }

    clampCamera();
},{ passive:false });

/***************************************************
 * (10) BLOCK INTERACTION (Unchanged)
 ***************************************************/
function handleBlockInteraction(e,action){
    if(!canInteract()) return;
    const rect= gameCanvas.getBoundingClientRect();
    const mouseX=((e.clientX-rect.left)/rect.width)*2-1;
    const mouseY=-(((e.clientY-rect.top)/rect.height)*2-1);

    const rayClip=[mouseX,mouseY,-1,1];
    const invProj=mat4.invert(mat4.create(), projectionMatrix);
    const rayView=vec4.transformMat4([], rayClip, invProj);
    rayView[2]=-1;
    rayView[3]=0;

    const viewMat=mat4.create();
    mat4.rotateX(viewMat, viewMat, cameraRotation[0]);
    mat4.rotateY(viewMat, viewMat, cameraRotation[1]);
    mat4.translate(viewMat, viewMat,[
        -cameraPosition[0],
        -cameraPosition[1],
        -cameraPosition[2]
    ]);

    const invView= mat4.invert(mat4.create(), viewMat);
    const rayWorld= vec3.normalize([], vec4.transformMat4([], rayView, invView));
    const rayOrigin=[...cameraPosition];

    let closestBlock=null;
    let closestDist= Infinity;
    blocks.forEach((b,i)=>{
        const [bx,by,bz]= b.position;
        const min=[bx-0.5, by-0.5, bz-0.5];
        const max=[bx+0.5, by+0.5, bz+0.5];

        const tMin=[];
        const tMax=[];
        for(let j=0;j<3;j++){
            if(rayWorld[j]!==0){
                tMin[j]=(min[j]-rayOrigin[j])/rayWorld[j];
                tMax[j]=(max[j]-rayOrigin[j])/rayWorld[j];
                if(tMin[j]>tMax[j]) [tMin[j],tMax[j]]=[tMax[j],tMin[j]];
            } else {
                tMin[j]= -Infinity;
                tMax[j]=  Infinity;
            }
        }
        const tEnter=Math.max(tMin[0], tMin[1], tMin[2]);
        const tExit=Math.min(tMax[0], tMax[1], tMax[2]);
        if(tEnter< tExit && tEnter>0 && tEnter<closestDist){
            closestDist=tEnter;
            closestBlock={ block:b, index:i };
        }
    });

    if(!closestBlock) return;
    const { block, index }= closestBlock;
    if(action==="delete"){
        if(block.deletable){
            blocks.splice(index,1);
            destroyAudio.play();
        }
    } else {
        // add block
        const [bx,by,bz] = block.position;
        const hitPoint= vec3.add([], rayOrigin, vec3.scale([], rayWorld, closestDist));
        const dx= hitPoint[0]-bx;
        const dy= hitPoint[1]-by;
        const dz= hitPoint[2]-bz;

        let newPos=null;
        if(Math.abs(dx)>Math.abs(dy) && Math.abs(dx)>Math.abs(dz)){
            newPos=[bx+Math.sign(dx), by, bz];
        } else if(Math.abs(dy)>Math.abs(dx) && Math.abs(dy)>Math.abs(dz)){
            newPos=[bx, by+Math.sign(dy), bz];
        } else {
            newPos=[bx, by, bz+Math.sign(dz)];
        }

        if(newPos[0]<-50 || newPos[0]>=50 || newPos[2]<-50 || newPos[2]>=50){
            return;
        }

        const exists= blocks.some(b=>
            b.position[0]===newPos[0] &&
            b.position[1]===newPos[1] &&
            b.position[2]===newPos[2]
        );
        if(!exists){
            const chosenItem= hotbarItems[currentHotbarIndex];
            let blockTypeIdx=0;
            if(!chosenItem.isSpecialGrass){
                blockTypeIdx=currentHotbarIndex;
            }
            blocks.push({
                position:newPos,
                deletable:true,
                blockTypeIndex:blockTypeIdx
            });
            buildAudio.play();
        }
    }
}

/***************************************************
 * (11) PROJECTION & DRAW
 ***************************************************/
const projectionMatrix= mat4.create();
mat4.perspective(projectionMatrix, Math.PI/4, gameCanvas.width/gameCanvas.height, 0.1,1000);

function handleCameraMovement() {
    if (!canInteract()) return;

    const speed=0.1;
    const yaw  = cameraRotation[1];

    // forward => [-Math.sin(yaw), 0, -Math.cos(yaw)]
    // right   => [ Math.cos(yaw), 0, -Math.sin(yaw)]
    const forward = [
        Math.sin(yaw),
        0,
        -Math.cos(yaw)
    ];
    const right = [
        Math.cos(yaw),
        0,
        Math.sin(yaw)
    ];

    // Save old position in case we revert on collision
    const oldX = cameraPosition[0];
    const oldY = cameraPosition[1];
    const oldZ = cameraPosition[2];

    // WASD
    if (keyMap["w"]) {
        cameraPosition[0] += forward[0]*speed;
        cameraPosition[2] += forward[2]*speed;
    }
    if (keyMap["s"]) {
        cameraPosition[0] -= forward[0]*speed;
        cameraPosition[2] -= forward[2]*speed;
    }
    if (keyMap["a"]) {
        cameraPosition[0] -= right[0]*speed;
        cameraPosition[2] -= right[2]*speed;
    }
    if (keyMap["d"]) {
        cameraPosition[0] += right[0]*speed;
        cameraPosition[2] += right[2]*speed;
    }

    // If noClip is off => naive collision check => revert if inside block
    if (!noClip && isCameraInsideAnyBlock(cameraPosition)) {
        cameraPosition[0] = oldX;
        cameraPosition[1] = oldY;
        cameraPosition[2] = oldZ;
    }

    clampCamera();
}

function isCameraInsideAnyBlock(pos) {
    // We'll treat camera as sphere radius=0.3,
    // each block as sphere radius=0.5 => collisionDist=0.8
    const cameraRadius= 0.3;
    const blockRadius = 0.5;
    const collisionDist= cameraRadius + blockRadius;

    for (let i=0; i<blocks.length; i++){
        const [bx,by,bz] = blocks[i].position;
        const dx= pos[0] - bx;
        const dy= pos[1] - by;
        const dz= pos[2] - bz;
        const dist= Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (dist < collisionDist) {
            return true; // inside a block
        }
    }
    return false;
}



function drawScene(){
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    if(gameState==="ingame"){
        handleCameraMovement();

        const baseMV= mat4.create();
        mat4.rotateX(baseMV, baseMV, cameraRotation[0]);
        mat4.rotateY(baseMV, baseMV, cameraRotation[1]);
        mat4.translate(baseMV, baseMV, [
            -cameraPosition[0],
            -cameraPosition[1],
            -cameraPosition[2]
        ]);

        gl.uniformMatrix4fv(uProjLoc,false,projectionMatrix);

        // (A) Draw large plane => y=-0.5 => grass
        {
            gl.bindBuffer(gl.ARRAY_BUFFER, outerPlaneVBO);
            gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, outerPlaneIBO);

            // faceType=0 => uses grass
            gl.uniform1i(uBlockType, 0);

            const planeMV= mat4.clone(baseMV);
            gl.uniformMatrix4fv(uMVLoc,false, planeMV);

            const PLANE_STRIDE= 6*FLOAT_SIZE;
            const PLANE_POS_OFF= 0;
            const PLANE_UV_OFF=  3*FLOAT_SIZE;
            const PLANE_FT_OFF=  5*FLOAT_SIZE;

            gl.vertexAttribPointer(aPosLoc,3,gl.FLOAT,false,PLANE_STRIDE,PLANE_POS_OFF);
            gl.enableVertexAttribArray(aPosLoc);

            gl.vertexAttribPointer(aUVLoc,2,gl.FLOAT,false,PLANE_STRIDE,PLANE_UV_OFF);
            gl.enableVertexAttribArray(aUVLoc);

            gl.vertexAttribPointer(aFaceLoc,1,gl.FLOAT,false,PLANE_STRIDE,PLANE_FT_OFF);
            gl.enableVertexAttribArray(aFaceLoc);

            gl.drawElements(gl.TRIANGLES,6,gl.UNSIGNED_SHORT,0);
        }

        // (B) Draw 100×100 blocks
        blocks.forEach(({ position:[bx,by,bz], blockTypeIndex })=>{
            const mv= mat4.clone(baseMV);
            mat4.translate(mv, mv, [bx, by, bz]);
            gl.uniformMatrix4fv(uMVLoc,false,mv);

            if(blockTypeIndex===0){
                // grass/dirt geometry
                gl.bindBuffer(gl.ARRAY_BUFFER, grassDirtVBO);
                gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, grassDirtIBO);
            } else {
                // single-texture => faceType=2
                gl.bindBuffer(gl.ARRAY_BUFFER, singleVBO);
                gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, singleIBO);
                gl.uniform1i(uBlockType, blockTypeIndex);
            }

            gl.vertexAttribPointer(aPosLoc,3,gl.FLOAT,false,STRIDE,0);
            gl.enableVertexAttribArray(aPosLoc);

            gl.vertexAttribPointer(aUVLoc,2,gl.FLOAT,false,STRIDE,12);
            gl.enableVertexAttribArray(aUVLoc);

            gl.vertexAttribPointer(aFaceLoc,1,gl.FLOAT,false,STRIDE,20);
            gl.enableVertexAttribArray(aFaceLoc);

            gl.drawElements(gl.TRIANGLES,36,gl.UNSIGNED_SHORT,0);
        });
    }

    requestAnimationFrame(drawScene);
}



drawScene();
setGameState("mainmenu");
